
# Camera capture node
Captures the frames of a camera by its name in the stage
