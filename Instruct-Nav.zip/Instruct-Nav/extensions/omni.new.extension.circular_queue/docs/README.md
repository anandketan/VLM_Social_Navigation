
# Circular queue node
This omnigraph node implements a circular queue of a particular size.