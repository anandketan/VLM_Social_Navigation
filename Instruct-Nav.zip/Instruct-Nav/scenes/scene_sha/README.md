# Scene: Simple Human Avoidance

**Motion**: In this condition, the robot will be asked to navigate forward, while a human will walk across the narrow corridor temporally blocking the path of the robot. 

**Instruction**: The instruction will be simple and would not refer to any visual cues in the environment
